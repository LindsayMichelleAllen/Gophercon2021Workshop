INSERT INTO journal (time, login, content) VALUES ('%s', '%s', '%s');
