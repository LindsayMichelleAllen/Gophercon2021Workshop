SELECT time, login, content
FROM journal
WHERE time >= '%s' AND time <= '%s'
;
